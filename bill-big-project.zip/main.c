#include <stdio.h>
int cid=0;
int pid=0;
int bid=0;
//Customer id
struct Customer
{
    char cusName[50];
    char cusPhno[10];
    int cusId;
   
}cus[100];
//Product id
struct Product
{
     char proName[50];
    int proQuantity;
    int proId;
    int proPrize;
}pro[100];
struct Bill
{
    int cId;
    int noPro;
    struct Item
    {
        int itmId;
        int itmQuantity;
    }itm[100];
}bill[100];
//function create Customer
void createCustomer()
{
    printf("Enter Your Name: ");
    scanf("%s",cus[cid].cusName);
    printf("Enter Your Number: ");
    scanf("%s",cus[cid].cusPhno);
    cus[cid].cusId=cid+1;
    printf("=====>Data Entered Successfully<====");
    cid++;
}
// function display Customer
void displayCustomers()
{
    for(int i=0;i<cid;i++)
    {
        
        printf("Customer Id: %d\n",cus[i].cusId);
        printf("Customer Name: %s\n",cus[i].cusName);
        printf("Customer Phone Number: %s\n",cus[i].cusPhno);
        
    }
}

void createProduct()
{
    printf("Enter Product Name: ");
    scanf("%s",pro[pid].proName);
    printf("Enter Product Quantity: ");
    scanf("%d",&pro[pid].proQuantity);
    printf("Enter Product Prize: ");
    scanf("%d",&pro[pid].proPrize);
    pro[pid].proId=pid+1;
    printf("=====>Data Entered Successfully<====");
    pid++;
}
void displayProduct()
{
    for(int i=0;i<pid;i++)
    {
        
        printf("Product Id: %d\n",pro[i].proId);
        printf("Product Name: %s\n",pro[i].proName);
        printf("Product Quantity: %d\n",pro[i].proQuantity);
        
    }
}
/*void billing()
{
    printf(Enter the )
}*/

int main()
{
    while(1)
    {
        int n;
        printf(" 1)Create Customer\n 2)Display Customer\n 3)Create Product\n 4)Display Product\n 5)billing:");
        scanf("%d",&n);
        switch(n)
        {
            case 1:{
               createCustomer();
               break;
            }
            case 2:{
                displayCustomers();
                break;
            }
            case 3:
            {
                createProduct();
                break;
            }
            case 4:
            {
                displayProduct();
                break;
            }
           /* case 5:
            {
                billing();
                break;
            }*/
        }
    }
return 0;
}